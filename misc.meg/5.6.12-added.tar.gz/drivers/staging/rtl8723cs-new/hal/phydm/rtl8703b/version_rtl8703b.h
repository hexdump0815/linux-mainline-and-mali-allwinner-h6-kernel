/* SPDX-License-Identifier: GPL-2.0 */
/*RTL8703B PHY Parameters*/
/*
[Caution]
  Since 01/Aug/2015, the commit rules will be simplified.
  You do not need to fill up the version.h anymore,
  only the maintenance supervisor fills it before formal release.
*/
#define	RELEASE_DATE_8703B		20150915
#define	COMMIT_BY_8703B			"BB_Luke"
#define	RELEASE_VERSION_8703B	17
